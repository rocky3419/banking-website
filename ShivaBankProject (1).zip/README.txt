
# Shiva Bank Project

## Backend
- Spring Boot (Java 17+)
- Oracle Database Integration
- REST APIs for Register & View Users

## Frontend
- Simple HTML forms (no frameworks)
- `register.html` — Register new user
- `admin-dashboard.html` — View all registered users

## Oracle DB Setup
- Username: system
- Password: 1234
- SID/Service: xe
- Port: 1521

## How to Run
1. Start Oracle DB locally
2. Update application.properties if needed
3. Run Spring Boot app (`mvn spring-boot:run` or via IDE)
4. Open `register.html` or `admin-dashboard.html` in browser

## API Endpoints
- `POST /register`
- `GET /api/users`
