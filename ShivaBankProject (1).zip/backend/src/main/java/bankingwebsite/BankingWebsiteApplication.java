
package bankingwebsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingWebsiteApplication {
    public static void main(String[] args) {
        SpringApplication.run(BankingWebsiteApplication.class, args);
    }
}
