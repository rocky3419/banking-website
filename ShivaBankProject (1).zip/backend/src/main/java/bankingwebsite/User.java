
package bankingwebsite;

import jakarta.persistence.*;

@Entity
@Table(name = "BANK_USER")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String fullName;
    private String username;
    private String email;
    private String phone;
    private String dob;
    private String gender;
    private String password;
    private String securityQuestion;
    private String securityAnswer;

    // Getters and Setters
    // (omitted for brevity)
}
